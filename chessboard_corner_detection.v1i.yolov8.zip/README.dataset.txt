# chessboard corner detection > 2023-05-02 12:22am
https://universe.roboflow.com/chessreff/chessboard-corner-detection

Provided by a Roboflow user
License: CC BY 4.0

